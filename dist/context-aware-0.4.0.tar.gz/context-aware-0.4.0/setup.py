from setuptools import setup

setup(
    name="context_aware",  # kept for legacy/editable installs if needed
)
